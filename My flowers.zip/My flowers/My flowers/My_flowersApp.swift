//
//  My_flowersApp.swift
//  My flowers
//
//  Created by saeq15717 on 2022-11-28.
//

import SwiftUI
import Firebase

@main
struct My_flowersApp: App {
    @StateObject var dataManager = DataManager()
    init() {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            myFlowersListView()
                .environmentObject(dataManager)
        }
    }
}
