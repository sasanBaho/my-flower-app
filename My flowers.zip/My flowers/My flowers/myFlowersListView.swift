//
//  ContentView.swift
//  My flowers
//
//  Created by saeq15717 on 2022-11-28.
//

import SwiftUI

struct myFlowersListView: View {
    @EnvironmentObject var dataManager: DataManager
        
    var body: some View {
        NavigationView {
            List(dataManager.flowers, id: \.id) { flower in
                HStack {
                    Text("by: \(flower.username)")
                    Image(flower.image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 130)
                        .cornerRadius(10)
                    VStack (alignment: .leading, spacing: 5){
                        Text(flower.description)
                            .fontWeight(.semibold)
                            .lineLimit(2)
                            .font(.system(size: 14))
                        
                        Text("Next watering: \(flower.nextDate)")
                            .font(.system(size: 14))
                            .foregroundColor(.green)
                        
                        Text("last watering: \(flower.previousDate)")
                            .font(.system(size: 12))
                            .foregroundColor(.secondary)
                        
                        Text("by: \(flower.username)")
                            .font(.system(size: 12))
                            .foregroundColor(.secondary)
                    }
                }
                .listRowInsets(EdgeInsets(top: 10, leading: 0, bottom: 10, trailing: 0))
            }
            .navigationBarTitle(Text("My falowers list"), displayMode: .large)
            .navigationBarItems(trailing:
                Button(action: {
                    print("go to flower add view")
                }) {
                    Text("Add flower")
                    Image(systemName: "leaf.circle").imageScale(.large)
                        .font(.system(size: 20.0))
                }
            )
            
        }.ignoresSafeArea()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        myFlowersListView()
    }
}
