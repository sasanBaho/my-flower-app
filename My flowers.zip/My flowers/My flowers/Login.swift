//
//  Login.swift
//  My flowers
//
//  Created by saeq15717 on 2022-12-05.
//

import SwiftUI
import Firebase

struct Login: View {
    @State private var email = ""
    @State private var password = ""
    @State private var userIsLogedIn = false
    
    var body: some View {
        if userIsLogedIn {
            myFlowersListView()
        } else {
            content
        }
    }
    
    var content: some View {
        VStack {
            Text("Welcome")
                .font(.system(size: 40))
            
            
            TextField("", text: $email)
                .frame(height: 40)
                .foregroundColor(.black)
                .textFieldStyle(.plain)
                .background(.green)
                .opacity(0.6)
                .padding(.horizontal, 50 )
                
            TextField("", text: $password)
                .frame(height: 40)
                .foregroundColor(.black)
                .textFieldStyle(.plain)
                .background(.green)
                .opacity(0.6)
                .padding(.horizontal, 50 )
                .padding(.vertical)
                
            
            Button {
                register()
            } label: {
                Text("Sign up")
                    .bold()
                    .frame(width: 200, height: 40)
                    .background(
                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .fill(.blue)
                    )
                    .foregroundColor(.white)
            }.padding()
            
            Button {
                login()
            } label: {
                Text("Alraedy have account? Login")
                    .foregroundColor(.blue)
                    .underline()
            }
            
        }
        .onAppear {
            Auth.auth().addStateDidChangeListener { auth, user in
                if user != nil {
                    userIsLogedIn.toggle()
                }
            }
        }
    }
    
    func login() {
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if error != nil {
                print(error!.localizedDescription)
            }
        }
    }
    
    func register() {
        Auth.auth().createUser(withEmail: email, password: password) { rseult, error in
            if error != nil {
                print(error!.localizedDescription)
            }
        }
    }
}

struct Login_Previews: PreviewProvider {
    static var previews: some View {
        Login()
    }
}

