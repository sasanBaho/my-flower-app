//
//  flowerMoldel.swift
//  My flowers
//
//  Created by saeq15717 on 2022-11-28.
//

import Foundation

struct FlowerModel: Identifiable {
    let id = UUID()
    let description: String
    let nextDate: String
    let previousDate: String
    let username: String
    let image: String
}

struct FlowerList {
    static let myFlowerList = [
        FlowerModel(description: "Dinning room 1", nextDate: "Mon, Dec 07", previousDate: "Fri, Dec 01", username: "Sasan", image: "flower5"),
        FlowerModel(description: "Bedroom flower", nextDate: "Wed, Dec 11", previousDate: "Thu, Dec 06", username: "Razi", image: "flower2"),
        FlowerModel(description: "Front yard", nextDate: "Mon, Dec 02", previousDate: "Fri, Oct 30", username: "Sasan", image: "flower3"),
        FlowerModel(description: "Balcony", nextDate: "Wed, Dec 11", previousDate: "Thu, Dec 06", username: "Sasan", image: "flower4"),
        FlowerModel(description: "Back yard", nextDate: "Wed, Dec 11", previousDate: "Thu, Dec 06", username: "Razi", image: "flower6")
    ]
}
