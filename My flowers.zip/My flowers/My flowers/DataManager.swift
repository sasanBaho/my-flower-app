//
//  DataManager.swift
//  My flowers
//
//  Created by saeq15717 on 2022-12-07.
//

import Foundation
import Firebase

class DataManager: ObservableObject {
    @Published var flowers: [FlowerModel] = []
    
    init() {
        fetchData()
    }
    
    func fetchData() {
        flowers.removeAll()
        let db = Firestore.firestore()
        let ref = db.collection("FlowerModel")
        ref.getDocuments { snapshot, error in
            guard error == nil else {
                print(error!.localizedDescription)
                return
            }
            if let snapshot = snapshot {
                for document in snapshot.documents {
                    let data = document.data()
                    
                    let description = data["description"] as? String ?? ""
                    let nextDate = data["nextDate"] as? String ?? ""
                    let previousDate = data["previousDate"] as? String ?? ""
                    let username = data["username"] as? String ?? ""
                    let image = data["image"] as? String ?? ""
                    
                    let flower = FlowerModel(description: description, nextDate: nextDate, previousDate: previousDate, username: username, image: image)
                    self.flowers.append(flower)
                }
            }
        }
    }
}
